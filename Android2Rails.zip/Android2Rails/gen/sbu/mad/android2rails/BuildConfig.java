/** Automatically generated file. DO NOT MODIFY */
package sbu.mad.android2rails;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}